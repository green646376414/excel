package net.sppan.base.controller.exl;

import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class exlController {
    @RequestMapping(value="/exportXls", method = RequestMethod.GET)
    public void exportXls(HttpServletResponse response) throws IOException {
        String message = "下载文件失败";
        try{
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("utf-8");
            String fileName = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 7);
            response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
            //获取测试数据
            List<ExcelDto> excelDtoList = getExcelDtoList();
            //合并策略map
            Map<String, List<RowRangeDto>> strategyMap = ExcelUtil.addMerStrategy(excelDtoList);
            EasyExcel.write(response.getOutputStream(), ExcelDto.class)
                    //注册合并策略
                    .registerWriteHandler(new BizMergeStrategy(strategyMap))
                    .sheet("Sheet1").doWrite(excelDtoList);
        }catch (Exception e) {
            e.printStackTrace();
            // 重置response
            response.reset();
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            response.getWriter().println(JSON.toJSONString("JsonResponse.fail(message)"));
        }
    }

    private List<ExcelDto> getExcelDtoList() {
        return JSONArray.parseArray("[{\"applyCount\":2,\"avgTime\":12.5,\"bizUnit\":\"-\",\"connCount\":2,\"connRate\":1,\"coopOrg\":\"蔚蓝\",\"orgName\":\"朝阳支行\",\"signerName\":\"admin\"},{\"applyCount\":1,\"avgTime\":0,\"bizUnit\":\"北京\",\"connCount\":0,\"connRate\":0,\"coopOrg\":\"长安新生\",\"orgName\":\"朝阳支行\",\"signerName\":\"admin\"},{\"applyCount\":1,\"avgTime\":11,\"bizUnit\":\"山西\",\"connCount\":1,\"connRate\":1,\"coopOrg\":\"长安新生\",\"orgName\":\"朝阳支行\",\"signerName\":\"admin\"},{\"applyCount\":2,\"avgTime\":0,\"bizUnit\":\"北京\",\"connCount\":0,\"connRate\":0,\"coopOrg\":\"长安新生\",\"orgName\":\"丰台支行\",\"signerName\":\"张三\"},{\"applyCount\":1,\"avgTime\":0,\"bizUnit\":\"-\",\"connCount\":0,\"connRate\":0,\"coopOrg\":\"蔚蓝\",\"orgName\":\"朝阳支行\",\"signerName\":\"张三\"},{\"applyCount\":2,\"avgTime\":0,\"bizUnit\":\"北京\",\"connCount\":0,\"connRate\":0,\"coopOrg\":\"长安新生\",\"orgName\":\"朝阳支行\",\"signerName\":\"张三\"},{\"applyCount\":1,\"avgTime\":0,\"bizUnit\":\"山西\",\"connCount\":0,\"connRate\":0,\"coopOrg\":\"长安新生\",\"orgName\":\"朝阳支行\",\"signerName\":\"张三\"}]", ExcelDto.class);
    }

}
